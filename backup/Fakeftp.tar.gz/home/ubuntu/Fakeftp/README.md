# Fakeftp
FTP Honeypot : Fake ftp server to attract hackers

## For more information serach `IHA089` on your browser
