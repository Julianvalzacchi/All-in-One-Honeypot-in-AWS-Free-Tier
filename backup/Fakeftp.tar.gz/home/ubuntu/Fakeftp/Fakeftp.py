import socket
import random
import threading
import string
import sys
import logging
import os
from datetime import datetime

log_file = 'fake_ftp.log'
logging.basicConfig(filename=log_file, level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s')

def get_target_info(ip):
    try:
        hostname = socket.gethostbyaddr(ip)
        log_message = f"Target hostname: {hostname}"
        print(log_message)
        logging.info(log_message)
    except socket.herror:
        log_message = f"Could not resolve hostname for {ip}"
        print(log_message)
        logging.info(log_message)

def GEN_RANDOM_STR(length):
    characters = string.ascii_letters + string.digits + string.punctuation + " "
    return ''.join(random.choice(characters) for _ in range(length))

def handle_client(conn, addr, file_list, dir_list):
    ip, port = addr
    pwd = [socket.gethostname()]
    USERNAMES = ["admin", "user", "Admin", "Administrator", "administrator", "anonymous", "Anonymous"]
    PASSWORDS = ["admin", "pass", "Admin", "Administrator", "administrator", "anonymous", "Anonymous", "1234"]
    conn.send("220 Welcome to Farmacia Paafín's FTP server\r\n".encode('utf-8'))
    logging.info(f"[{ip}:{port}] Incoming connection.")

    authenticated = False
    data_conn = None
    username = None

    while True:
        try:
            data = conn.recv(1024)
            if not data:
                break

            command = data.decode().strip()
            log_message = f"[{ip}:{port}] Received: {command}"
            print(log_message)
            logging.info(log_message)

            if command.startswith("USER"):
                parts = command.split()
                if len(parts) >= 2:
                    username = parts[1]
                    if username in USERNAMES:
                        conn.send("331 Username OK, need password\r\n".encode('utf-8'))
                    else:
                        conn.send("530 Invalid username\r\n".encode('utf-8'))
                else:
                    conn.send("501 Syntax error in USER command\r\n".encode('utf-8'))

            elif command.startswith("PASS"):
                parts = command.split()
                if len(parts) >= 2:
                    password = parts[1]
                    if password in PASSWORDS:
                        authenticated = True
                        conn.send("230 Login successful\r\n".encode('utf-8'))
                        logging.info(f"[{ip}:{port}] Authenticated as {username}:{password}")
                    else:
                        conn.send("530 Invalid password\r\n".encode('utf-8'))
                else:
                    conn.send("501 Syntax error in PASS command\r\n".encode('utf-8'))

            elif command.startswith("PORT"):
                parts = command.replace("PORT ", "").split(',')
                if len(parts) == 6:
                    ip_address = '.'.join(parts[:4])
                    port = int(parts[4]) * 256 + int(parts[5])
                    try:
                        data_conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        data_conn.connect((ip_address, port))
                        conn.send("200 PORT command successful\r\n".encode('utf-8'))
                    except ConnectionRefusedError:
                        conn.send("425 Cannot open data connection\r\n".encode('utf-8'))
                        data_conn = None
                else:
                    conn.send("500 Invalid PORT command format\r\n".encode('utf-8'))

            elif authenticated:
                parts = command.split()
                if len(parts) == 0:
                    conn.send("500 Unknown command\r\n".encode('utf-8'))
                    continue

                cmd = parts[0].upper()

                if cmd in ["PUT", "STOR"] and len(parts) == 2:
                    filename = parts[1]
                    log_message = f"[{ip}:{port}] Target uploading file {filename}"
                    print(log_message)
                    logging.info(log_message)
                    conn.send("150 File status okay; about to open data connection\r\n".encode('utf-8'))
                    if data_conn:
                        data_received = b''
                        while True:
                            chunk = data_conn.recv(1024)
                            if not chunk:
                                break
                            data_received += chunk
                        data_conn.close()
                        conn.send("226 Transfer complete\r\n".encode('utf-8'))
                        log_message = "-------------------------File Content--------------------------------\n" + data_received.decode(errors='ignore') + "\n-------------------------------------------------------------------------------"
                        print(log_message)
                        logging.info(log_message)
                    else:
                        conn.send("425 Cannot open data connection\r\n".encode('utf-8'))

                elif cmd in ["GET", "SIZE"] and len(parts) == 2:
                    file_size = random.randint(700, 900)
                    conn.send(f"213 {file_size}\r\n".encode('utf-8'))

                elif cmd == "RETR" and len(parts) == 2:
                    d_file = parts[1]
                    if data_conn:
                        if d_file in file_list:
                            data = GEN_RANDOM_STR(file_size)
                            data_conn.sendall(data.encode('utf-8'))
                            data_conn.close()
                            conn.send("226 Transfer complete\r\n".encode('utf-8'))
                        elif d_file in dir_list:
                            data_conn.close()
                            conn.send(f"570 {d_file} is a directory\r\n".encode('utf-8'))
                        else:
                            data_conn.close()
                            conn.send(f"550 {d_file} not found\r\n".encode('utf-8'))
                    else:
                        conn.send("425 Cannot open data connection\r\n".encode('utf-8'))

                elif cmd in ["MKDIR", "MKD"] and len(parts) == 2:
                    dirname = parts[1]
                    log_message = f"[{ip}:{port}] Target trying to create directory: {dirname}"
                    print(log_message)
                    logging.info(log_message)
                    if dirname in dir_list:
                        conn.send("550 Directory already exists\r\n".encode('utf-8'))
                    else:
                        dir_list.append(dirname)
                        conn.send("257 Directory created\r\n".encode('utf-8'))

                elif cmd in ["DELETE", "DELE"] and len(parts) == 2:
                    item = parts[1]
                    log_message = f"[{ip}:{port}] Target trying to delete: {item}"
                    print(log_message)
                    logging.info(log_message)
                    if "." in item:
                        if item in file_list:
                            file_list.remove(item)
                            conn.send(f"250 File \"{item}\" successfully deleted\r\n".encode('utf-8'))
                        else:
                            conn.send(f"550 File \"{item}\" not found\r\n".encode('utf-8'))
                    else:
                        if item in dir_list:
                            dir_list.remove(item)
                            conn.send(f"250 Directory \"{item}\" successfully deleted\r\n".encode('utf-8'))
                        else:
                            conn.send(f"550 Directory \"{item}\" not found\r\n".encode('utf-8'))

                elif cmd in ["RENAME", "RNFR"] and len(parts) == 2:
                    rename_from = parts[1]
                    conn.send("350 Ready for RNTO\r\n".encode('utf-8'))

                elif cmd == "RNTO" and len(parts) == 2 and 'rename_from' in locals():
                    rename_to = parts[1]
                    log_message = f"[{ip}:{port}] Renaming from {rename_from} to {rename_to}"
                    print(log_message)
                    logging.info(log_message)
                    try:
                        if rename_from in file_list:
                            file_list.remove(rename_from)
                            file_list.append(rename_to)
                            conn.send("250 Rename successful\r\n".encode('utf-8'))
                        elif rename_from in dir_list:
                            dir_list.remove(rename_from)
                            dir_list.append(rename_to)
                            conn.send("250 Rename successful\r\n".encode('utf-8'))
                        else:
                            conn.send("550 Rename failed\r\n".encode('utf-8'))
                    except OSError as e:
                        conn.send(f"550 Rename failed: {e}\r\n".encode('utf-8'))
                    rename_from = None

                elif cmd == "PWD":
                    current_dir = "/" + "/".join(pwd)
                    conn.send(f"257 \"{current_dir}\" is the current directory\r\n".encode('utf-8'))

                elif cmd in ["LS", "DIR", "LIST"]:
                    log_message = f"[{ip}:{port}] Listing files or directories"
                    print(log_message)
                    logging.info(log_message)
                    response = "\r\n".join(file_list + dir_list) + "\r\n"
                    conn.send("150 Here comes the directory listing\r\n".encode('utf-8'))
                    if data_conn:
                        data_conn.sendall(response.encode('utf-8'))
                        data_conn.close()
                        conn.send("226 Directory transfer OK\r\n".encode('utf-8'))
                    else:
                        conn.send("425 Cannot open data connection\r\n".encode('utf-8'))

                elif cmd in ["CD", "CWD"] and len(parts) == 2:
                    target_dir = parts[1]
                    log_message = f"[{ip}:{port}] Changing to directory: {target_dir}"
                    print(log_message)
                    logging.info(log_message)
                    if target_dir == "..":
                        if len(pwd) > 1:
                            pwd.pop()
                        conn.send("250 Directory successfully changed\r\n".encode('utf-8'))
                    elif target_dir in dir_list:
                        pwd.append(target_dir)
                        conn.send("250 Directory successfully changed\r\n".encode('utf-8'))
                    else:
                        conn.send("550 Directory not found\r\n".encode('utf-8'))

                elif cmd == "QUIT":
                    conn.send("221 Goodbye\r\n".encode('utf-8'))
                    log_message = f"[{ip}:{port}] Connection closed by target."
                    print(log_message)
                    logging.info(log_message)
                    break

                else:
                    conn.send("500 Unknown command\r\n".encode('utf-8'))
            else:
                conn.send("530 Please login with USER and PASS\r\n".encode('utf-8'))
        except (ConnectionResetError, BrokenPipeError):
            log_message = f"[{ip}:{port}] Connection forcibly closed by client."
            print(log_message)
            logging.info(log_message)
            break
        except Exception as e:
            log_message = f"[{ip}:{port}] Error handling client: {e}"
            print(log_message)
            logging.error(log_message)
            break

    if data_conn:
        try:
            data_conn.close()
        except:
            pass
    conn.close()

def home_logo():
    logo = """
    #########################################
    #                                       #
    #         Servidor FTP de               #
    #             Farmacia Paafín           #
    #                                       #
    #########################################
    """
    print(logo)
    logging.info(logo.strip().replace('\n', ' '))

def FILES(Type):
    if Type == "file":
        return [
            "medicamento1.txt", "receta.pdf", "prospecto.doc", "pedido.csv",
            "ofertas.txt", "catalogo.pdf", "stock.xlsx", "envio.txt"
        ]
    elif Type == "dir":
        return ["Clientes", "Proveedores", "Pedidos", "Informes"]

def get_network_ip():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    except OSError:
        log_message = "No Internet connection..."
        print(log_message)
        logging.warning(log_message)
        return None
    finally:
        sock.close()

def ftp_server():
    my_ip = get_network_ip()
    if my_ip:
        home_logo()
        file_list = random.sample(FILES("file"), random.randint(5, 8))
        dir_list = random.sample(FILES("dir"), random.randint(2, 3))
        PORT = 21
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((my_ip, PORT))
        server.listen()
        log_message = f"Fake FTP server started on {my_ip}:{PORT}..."
        print(log_message)
        logging.info(log_message)

        while True:
            try:
                conn, addr = server.accept()
                log_message = f"Connection from {addr[0]}:{addr[1]}"
                print(log_message)
                logging.info(log_message)
                get_target_info(addr[0])
                threading.Thread(target=handle_client, args=(conn, addr, file_list, dir_list)).start()
            except KeyboardInterrupt:
                log_message = "Server stopped."
                print(log_message)
                logging.info(log_message)
                server.close()
                sys.exit()
    else:
        sys.exit()

if __name__ == "__main__":
    ftp_server()
