#!/bin/bash
source /home/ubuntu/secreto

###############################FUNCIONES########################################

function log_attemp() {
    while IFS= read -r line; do
        # Extraer datetime, ip e ipr
        datetime=$(echo "$line" | awk '{print $1 " " $2}' | awk -F"," '{print $1}')
        ptr=$(echo "$line" | grep "Target hostname" | awk -F"[()']+" '{print $2}')
        ip=$(echo "$line" | grep "Target hostname" | awk -F"[()']+" '{print $4}')

        # Saltar líneas que no contienen los datos esperados
        if [[ -z "$ptr" || -z "$ip" ]]; then
            continue
        fi

        # Insertar en la base de datos
        mysql -u "$mysql_user" -p"$mysql_passwd" -e \
            "USE ftp; INSERT INTO attem (ip, ptr, time) VALUES ('$ip', '$ptr', '$datetime');"

    done < $logs
}

function log_user() {
    while IFS= read -r line; do
        # Extraer user (limpiar espacios con xargs)
        user=$(echo "$line" | grep "USER" | awk '{print $9}' | xargs)

        # Saltar líneas sin usuario
        if [[ -z "$user" ]]; then
            continue
        fi

        # Insertar en la base de datos
        mysql -u "$mysql_user" -p"$mysql_passwd" -e \
            "USE ftp; INSERT INTO user (user, attemps) VALUES ('$user', 0);"

    done < $logs
}

function log_passwd() {
    while IFS= read -r line; do
        # Extraer user (limpiar espacios con xargs)
        pass=$(echo "$line" | grep "PASS" | awk '{print $9}' | xargs)
	echo $pass
        # Saltar líneas sin usuario
        if [[ -z "$pass" ]]; then
            continue
        fi

        # Insertar en la base de datos
        mysql -u "$mysql_user" -p"$mysql_passwd" -e \
            "USE ftp; INSERT INTO password (password, attemps) VALUES ('$pass', 0);"

    done < $logs
}

function log_command() {
    while IFS= read -r line; do
        # Extraer user (limpiar espacios con xargs)
        datetime=$(echo "$line" | awk '{print $1 " " $2}' | awk -F"," '{print $1}')
        command=$(echo "$line" | grep -E "STOR|RETR|LIST|MKD|RMD|DELE|SITE|PORT|CWD|PWD" | awk '{print $8 ": " $9}' | xargs)
        echo $command
        # Saltar líneas sin usuario
        if [[ -z "$command" ]]; then
            continue
        fi

        # Insertar en la base de datos
        mysql -u "$mysql_user" -p"$mysql_passwd" -e \
            "USE ftp; INSERT INTO command (command, time) VALUES ('$command', '$datetime');"

    done < $logs
}

#################################PROGRAMA PRINCIPAL##########################################
logs=/home/ubuntu/Fakeftp/fake_ftp.log
log_attemp
log_user
log_passwd
log_command
