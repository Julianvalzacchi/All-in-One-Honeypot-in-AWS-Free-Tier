<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sospechosos', function (Blueprint $table) {
            $table->id();
            $table->string('ip')->nullable();;
            $table->string('pais')->nullable();;
            $table->string('region')->nullable();;
            $table->string('ciudad')->nullable();;
            $table->string('codigo_postal')->nullable();
            $table->string('latitud')->nullable();;
            $table->string('longitud')->nullable();;
            $table->integer('cantidad')->nullable();;
            $table->string('SO')->nullable();;
            $table->string('navegador')->nullable();;
            $table->timestamps();
        });
    }

    public function down(): void
    {
        //
    }
};