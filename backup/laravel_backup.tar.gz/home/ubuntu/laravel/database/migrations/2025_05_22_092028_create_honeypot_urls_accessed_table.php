use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('honeypot_urls_accessed', function (Blueprint $table) {
            $table->id();
            $table->ipAddress('ip'); // La IP del atacante
            $table->string('url', 255); // La URL a la que se accedió
            $table->timestamps(); // created_at y updated_at
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('honeypot_urls_accessed');
    }
};
