<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Stevebauman\Location\Facades\Location;
use Jenssegers\Agent\Agent;
use Illuminate\Support\Facades\Cache;

class Manejar extends Controller
{
    protected function detectPathTraversal($value)
    {
        return is_string($value) && preg_match('/(\.\.\/|\.\/)+etc\/(passwd|group)/i', $value);
    }

    protected function detectSQLi($username, $password)
    {
        if (!is_string($username) || !is_string($password)) {
            return false;
        }

        $pattern = '~(\'|")\s*(or|and)\s*(\'|")?\d+\s*=\s*\d+|union\s+select|select\s+.*\s+from|insert\s+into|update\s+\w+\s+set|delete\s+from|drop\s+table|--|#|/\*|\*/~i';
        return preg_match($pattern, $username) || preg_match($pattern, $password);
    }

    public function guardar(Request $request)
    {
        $ip = $request->ip();
        $key = 'honeypot_attempts_' . $ip;
        $maxAttempts = 7;
        $decaySeconds = 10;
        $attempts = Cache::get($key, 0);
        $SQLuser = $request->usuario;
        $SQLpasswd = $request->contrasena;
        Cache::put($key, $attempts + 1, $decaySeconds);

        $sospechoso = false;
        $injection = false;
        $motivo = null;

        if ($request->isMethod('get') && $request->path() !== '/') {
            DB::table('honeypot_urls_accessed')->insert([
                'ip' => $ip,
                'url' => '/' . $request->path(),
                'created_at' => now(),
            ]);
	    $motivo = "Uso de ruta poco común";
	    $sospechoso = true;
        }


        if (!empty($request->input('oculto'))) {
            $motivo = "Rellenar formulario oculto";
            $sospechoso = true;
        } elseif ($attempts >= $maxAttempts) {
            $motivo = "Intentos muy seguidos";
            $sospechoso = true;
        }

        $dataToCheck = array_merge($request->all(), $request->query(), $request->headers->all());

        foreach ($dataToCheck as $key => $value) {
            if (is_array($value)) {
                $value = implode(' ', $value);
            }
            if ($this->detectPathTraversal($value)) {
                $motivo = "Patrón de path traversal detectado en: " . $key;
                $sospechoso = true;
                break;
            }
        }

        if ($this->detectSQLi($SQLuser, $SQLpasswd)) {
            $motivo = "Patrón de SQLi detectado: ";
            $sospechoso = true;
            $injection = true;
        }

        if ($sospechoso) {
            $posicion = Location::get($ip);
            $pais = $posicion->countryCode ?? null;
            $region = $posicion->regionName ?? null;
            $ciudad = $posicion->cityName ?? null;
            $codigo_postal = $posicion->postalCode ?? null;
            $latitud = $posicion->latitude ?? null;
            $longitud = $posicion->longitude ?? null;

            $agent = new Agent();
            $navegador = $agent->browser();
            $sistemaOperativo = $agent->platform();

            DB::table('sospechosos')->insert([
                'ip' => $ip,
                'cantidad' => 1,
                'pais' => $pais,
                'region' => $region,
                'ciudad' => $ciudad,
                'codigo_postal' => $codigo_postal,
                'latitud' => $latitud,
                'longitud' => $longitud,
                'SO' => $sistemaOperativo,
                'navegador' => $navegador,
                'motivo' => $motivo,
                'created_at' => now(),
            ]);

            Cache::forget($key);
        }

        if ($injection) {
            DB::table('sqli')->insert([
                'user' => $request->usuario,
                'passwd' => $request->contrasena,
                'created_at' => now(),
            ]);
            return redirect('/')->with('mensaje', 'Usuario y/o contraseña incorrectos, por favor vuelva intentarlo')->with('tiempo', 0);
        }

        if ($request->isMethod('post')) {
            DB::table('logs')->insert([
                'usuario' => $request->usuario,
                'contrasena' => $request->contrasena,
            ]);
            return redirect('/')->with('mensaje', 'Usuario y/o contraseña incorrectos, por favor vuelva intentarlo')->with('tiempo', 0);
        }

        return view('welcome');
    }
}
