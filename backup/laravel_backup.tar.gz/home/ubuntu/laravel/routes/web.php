<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Manejar;

Route::get('/', [Manejar::class, 'guardar']);
Route::get('/auth', [Manejar::class, 'guardar']);
Route::get('/wp-admin', [Manejar::class, 'guardar']);
Route::get('/wp-login.php', [Manejar::class, 'guardar']);
Route::get('/cpanel', [Manejar::class, 'guardar']);
Route::get('/phpmyadmin', [Manejar::class, 'guardar']);
Route::get('/dashboard', [Manejar::class, 'guardar']);
Route::get('/user/login', [Manejar::class, 'guardar']);
Route::get('/administrator', [Manejar::class, 'guardar']);
Route::get('/.env', [Manejar::class, 'guardar']);
Route::get('/backup', [Manejar::class, 'guardar']);
Route::get('/backups', [Manejar::class, 'guardar']);
Route::get('/site.zip', [Manejar::class, 'guardar']);
Route::get('/database.sql', [Manejar::class, 'guardar']);
Route::get('/config.php.bak', [Manejar::class, 'guardar']);
Route::get('/../', [Manejar::class, 'guardar']);
Route::get('/.././', [Manejar::class, 'guardar']);
Route::get('/../../etc/passwd', [Manejar::class, 'guardar']);
Route::get('/../../windows/win.ini', [Manejar::class, 'guardar']);
Route::get('/../var/log/apache2/access.log', [Manejar::class, 'guardar']);
Route::get('/uploads', [Manejar::class, 'guardar']);
Route::get('/downloads', [Manejar::class, 'guardar']);
Route::get('/access', [Manejar::class, 'guardar']);
Route::get('/images', [Manejar::class, 'guardar']);
Route::get('/login', [Manejar::class, 'guardar']);



Route::post('/guardar', [Manejar::class, 'guardar']);
