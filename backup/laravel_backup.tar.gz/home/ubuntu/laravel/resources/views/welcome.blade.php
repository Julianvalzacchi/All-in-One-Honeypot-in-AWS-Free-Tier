<!DOCTYPE html>
<html lang="es">

<head>
    <title>Empresa Farmacéutica Paafin</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
<style>
    @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap');

    body {
        background-color: #f4f8f6;
        background-image: url('/fondof.png');
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center center;
        background-attachment: fixed;
        font-family: 'Montserrat', sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        text-align: center;
        color: #333;
        transition: background-color 0.3s ease;
    }

    header {
        background-color: #2E7D32;
        color: white;
        padding: 1.5rem 0;
        font-size: 1.8rem;
        font-weight: bold;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        transition: background-color 0.3s ease, box-shadow 0.3s ease;
    }

    header:hover {
        background-color: #1B5E20;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    main {
        flex-grow: 1;
        padding: 2rem;
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;
        overflow: hidden;
    }

    .banner {
        position: absolute;
        top: 0;
        bottom: 0;
        background-repeat: repeat-y;
        background-size: auto;
        background-position: center;
        opacity: 0.7;
        transition: opacity 0.3s ease, transform 0.2s ease-in-out;
        z-index: 1;
        min-width: 50px;
    }

    .banner:hover {
/*        opacity: 0.9; */
        transform: scaleX(1.05);
    }

    .banner-left {
        left: 0;
        width: auto;
        background-image: url('/cruz.png');
    }

    .banner-right {
        right: 0;
        width: auto;
        background-image: url('/cruz.png');
    }

    .login-box {
        background-color: white;
        width: 300px;
        max-width: 90%;
        padding: 1.5rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        transition: box-shadow 0.3s ease, transform 0.2s ease-in-out;
        z-index: 10; 
    }

    .login-box:hover {
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2);
        transform: translateY(-2px);
    }

    .login-box h3 {
        font-size: 1.6rem;
        color: #388E3C;
        margin-bottom: 1rem;
    }

    .login-box input {
        width: calc(100% - 20px);
        padding: 0.8rem;
        margin: 0.7rem 0;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 1rem;
        box-sizing: border-box;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .login-box input:focus {
        border-color: #388E3C;
        outline: none;
        box-shadow: 0 0 0 0.2rem rgba(56, 142, 60, 0.25);
    }

    .login-box button {
        width: 100%;
        background-color: #388E3C;
        color: white;
        border: none;
        padding: 0.9rem;
        font-size: 1.1rem;
        border-radius: 6px;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.2s ease-in-out;
    }

    .login-box button:hover {
        background-color: #1B5E20;
        transform: scale(1.02);
    }

    @if(session('mensaje'))
    .login-box p {
        color: #d32f2f;
        margin-top: 0.5rem;
        font-size: 0.9rem;
    }
    @endif

    .image-container {
        display: none;
    }

    footer {
        background-color: #2E7D32;
        color: white;
        padding: 0.8rem 0;
        width: 100%;
        font-size: 0.9rem;
        transition: background-color 0.3s ease, opacity 0.3s ease;
        position: fixed;
        bottom: 0;
        z-index: 20;
    }

    footer:hover {
        background-color: #1B5E20;
        opacity: 0.95;
    }

    footer a {
        color: white;
        text-decoration: none;
        transition: text-decoration 0.3s ease;
    }

    footer a:hover {
        text-decoration: underline;
    }

    .hidden-link {
        display: none !important;
    }
</style>
</head>

<body>
    <header>Empresa Farmacéutica Paafin</header>

    <main>
        <div class="banner banner-left"></div>
        <div class="login-box">
            <h3>Iniciar Sesión</h3>
            <form action="{{ url('/guardar') }}" method="POST">
                @csrf
                <input type="text" placeholder="Usuario" name="usuario" id="usuario" autocomplete="off" required>
                <input type="password" placeholder="Contraseña" name="contrasena" id="contrasena" autocomplete="off" required>
		<!- Only for admins ->
                <input type="text" name="oculto" style="display: none;">
                <button type="submit">Ingresar</button>
            </form>

            @if(session('mensaje'))
                <p>{{ session('mensaje') }}</p>
            @endif
        </div>
        <div class="banner banner-right"></div>
        <div class="image-container">
            <img src="{{ asset('cruz.png') }}" alt="Cruz Central" style="width: 100%; max-width: 300px; height: auto; display: block; margin: 0 auto;">
        </div>
    </main>

    <footer>
	<!- More information ->
        <p>&copy; 2025 Empresa Farmacéutica Paafin</p>
        <a href="http://avppinball.com/prohopo/metallicpaint.php?link=4" style="display: none;">Solo trabajadores</a>
    </footer>
</body>
</html>
